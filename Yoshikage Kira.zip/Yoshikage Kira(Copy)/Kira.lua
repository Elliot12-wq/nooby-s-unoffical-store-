-- Kira.lua
-- Created with Moveset Creator V6
-- Place in: UhhhhhhReanim/Modules/Kira.lua

cloneref = cloneref or function(o) return o end

local Debris     = cloneref(game:GetService("Debris"))
local RunService = cloneref(game:GetService("RunService"))
local Players    = cloneref(game:GetService("Players"))
local UIS        = cloneref(game:GetService("UserInputService"))
local TS         = cloneref(game:GetService("TweenService"))

local Player = Players.LocalPlayer

local modules = {}
local function AddModule(m)
    table.insert(modules, m)
end

local function san_lua(s)
    return (s or ""):gsub("[^%w_]", "_")
end

AddModule(function()
    local m = {}
    m.ModuleType   = "MOVESET"
    m.Name         = "Yoshikage Kira"
    m.Description  = "I love Hands"
    m.InternalName = "Kira"

    m.Assets = {
        "Kage.anim",
        "NewRun.anim",
        "Test.anim",
        "HeartAttack.anim",
        "Skill_2_Acerto.anim",
        "Victim.anim",
        "Victim_BTD.anim",
        "Stand_BTD.anim", 
        "Skill_1.mp3",
        "Skill2_Victim.mp3",
        "Skill_3.mp3",
        "Awakening.anim",
        "Awk.mp3",
        "3_Skill_Base_U.anim",
        "3_Skill_Base_V.anim",
        "3_Skill_base.mp3"
    }

    m.FlingEnabled = {
        ["Sheer Heart Attack"] = false,
        ["Head Slam"] = false,
        ["Bite the Dust"] = false,
        ["Face Explosion"] = false,
    }

    m.Config = function(parent)
        Util_CreateText(parent, "Yoshikage Kira", 18, Enum.TextXAlignment.Center)
        Util_CreateSeparator(parent)
    end
    m.SaveConfig = function() return {} end
    m.LoadConfig = function(save) end

    -- STATE
    local baseAnims    = {}
    local actionAnims  = {}
    local actionStart  = {}
    local currentBase   = "idle"
    local currentAction = nil
    local wasInAir      = false
    local flingActive   = false
    local touchConns    = {}
    local allJoints     = {}
    local figureRef     = nil
    local SPEED_WALK    = 18
    local SPEED_SPRINT  = 30
    local isSprinting   = false
    local bgSound       = nil
    
    -- UI and Inputs
    local guiRef        = nil
    local dialogGuiRef  = nil
    local inputConn     = nil
    
    -- Per-animation sounds
    local snd_Sheer_Heart_Attack = nil
    local snd_Head_Slam = nil
    local snd_Face_Explosion = nil
    local snd_Bite_the_Dust = nil
    local sndRage       = nil
    local animRageEntry = nil
    
    -- Stun & Awk State
    local isStunned     = false
    local isRaging      = false
    local stunToken     = 0

    -- Victim State
    local activeVictims = {}

    -- Action Durations
    local actionDurations = {
        ["Sheer Heart Attack"] = 3,
        ["Head Slam"] = 3.5,
        ["Bite the Dust"] = 32,
        ["Face Explosion"] = 5,
        ["Awakening"] = 8.5
    }

    -- HELPERS
    local function makeSound(filename, parent, volume, looped)
        local s = Instance.new("Sound")
        s.SoundId = AssetGetContentId(filename)
        s.Volume  = volume or 0.8
        s.Looped  = looped or false
        s.Parent  = parent
        return s
    end

    local function loadAnim(fig, file, looped)
        local a = AnimLib.Animator.new()
        a.rig    = fig
        a.track  = AnimLib.Track.fromfile(AssetGetPathFromFilename(file))
        a.looped = looped or false
        a.speed  = 1
        a.weight = 0
        return a
    end

    local function setSpeed(speed)
        if not figureRef then return end
        local hum = figureRef:FindFirstChildOfClass("Humanoid")
        if hum then hum.WalkSpeed = speed end
    end

    local function applyStun(duration)
        stunToken = stunToken + 1
        local myToken = stunToken
        isStunned = true
        setSpeed(0)
        
        task.delay(duration, function()
            if stunToken == myToken then
                isStunned = false
                if isSprinting then
                    setSpeed(SPEED_SPRINT)
                else
                    setSpeed(SPEED_WALK)
                end
            end
        end)
    end

    local function getRandomPlayer()
        local plrs = Players:GetPlayers()
        local valid = {}
        for _, p in ipairs(plrs) do
            if p ~= Player and p.Character and p.Character:FindFirstChild("HumanoidRootPart") then
                table.insert(valid, p)
            end
        end
        if #valid > 0 then
            return valid[math.random(1, #valid)]
        end
        return nil
    end

    -- SISTEMA DE RIG EXCLUSIVO (Clonagem direta de aparência para performance e garantia no Client)
    local function spawnRigWithAppearance(targetPlayer, offsetCFrame, animName, duration)
        if not figureRef then return end
        
        task.spawn(function()
            local dummy
            
            -- Tenta clonar diretamente o Character do jogador para pegar visual idêntico no Client
            if targetPlayer and targetPlayer.Character then
                pcall(function()
                    targetPlayer.Character.Archivable = true
                    dummy = targetPlayer.Character:Clone()
                end)
            end
            
            -- Fallback: Se não houver player ou falhar, clona o próprio reanim do usuário
            if not dummy then
                pcall(function()
                    figureRef.Archivable = true
                    dummy = figureRef:Clone()
                end)
            end
            
            -- Fallback final
            if not dummy then
                dummy = Players:CreateHumanoidModelFromDescription(Instance.new("HumanoidDescription"), Enum.HumanoidRigType.R6)
            end
            
            dummy.Name = "SkillRig"
            dummy.Parent = workspace
            
            for _, v in ipairs(dummy:GetDescendants()) do
                if v:IsA("Script") or v:IsA("LocalScript") or v:IsA("Sound") or v:IsA("UIComponent") or v:IsA("ScreenGui") or v:IsA("BillboardGui") then 
                    v:Destroy()
                elseif v:IsA("BasePart") then
                    v.Massless = true
                    v.CanCollide = false
                    -- Apenas ancorar o HumanoidRootPart. Se ancorar tudo, as animações e CFrame falham!
                    if v.Name == "HumanoidRootPart" then
                        v.Anchored = true 
                    else
                        v.Anchored = false 
                    end
                end
            end
            
            local root = dummy:FindFirstChild("HumanoidRootPart") or dummy:FindFirstChild("Torso")
            local myRoot = figureRef:FindFirstChild("HumanoidRootPart") or figureRef:FindFirstChild("Torso")
            
            if root and myRoot then
                -- PivotTo garante que o modelo inteiro acompanhe a raiz com as joints intactas
                if dummy:IsA("Model") then
                    dummy.PrimaryPart = root
                    dummy:PivotTo(myRoot.CFrame * offsetCFrame)
                else
                    root.CFrame = myRoot.CFrame * offsetCFrame
                end
            end
            
            local dAnim = loadAnim(dummy, animName, false)
            dAnim.weight = 1
            
            table.insert(activeVictims, {
                anim = dAnim,
                dummy = dummy,
                start = os.clock()
            })
            
            Debris:AddItem(dummy, duration)
        end)
    end

    local function clearBase()
        for _, a in pairs(baseAnims) do a.weight = 0 end
    end

    local function setBase(state)
        if currentBase == state then return end
        currentBase = state
        clearBase()
        if baseAnims[state] then 
            baseAnims[state].weight = 1 
            actionStart[baseAnims[state]] = os.clock()
        end
    end

    local function stopAllAnimSounds()
        if snd_Sheer_Heart_Attack then snd_Sheer_Heart_Attack:Stop() end
        if snd_Head_Slam then snd_Head_Slam:Stop() end
        if snd_Face_Explosion then snd_Face_Explosion:Stop() end
        if snd_Bite_the_Dust then snd_Bite_the_Dust:Stop() end
        if sndRage then sndRage:Stop() end
    end

    local function stopAction()
        for _, anim in pairs(actionAnims) do anim.weight = 0 end
        if animRageEntry then animRageEntry.weight = 0 end
        stopAllAnimSounds()
        currentAction = nil
        flingActive   = false
    end

    -- DIALOG SYSTEM
    local function showDialog(name, text)
        if not dialogGuiRef then return end
        local dFrame = dialogGuiRef:FindFirstChild("DialogFrame")
        if dFrame then
            dFrame.NameLabel.Text = name
            dFrame.TextLabel.Text = text
            dialogGuiRef.Enabled = true
        end
    end

    local function hideDialog()
        if dialogGuiRef then dialogGuiRef.Enabled = false end
    end

    -- CUTSCENE LOGIC
    local function doAwakeningCutscene()
        isStunned = true
        setSpeed(0)
        currentAction = "Awakening"
        
        animRageEntry.weight = 1
        actionStart[animRageEntry] = os.clock()
        if sndRage then sndRage:Play() end
        
        -- Camera FOV Tween
        local camera = workspace.CurrentCamera
        local originalFOV = camera.FieldOfView
        local tweenIn = TS:Create(camera, TweenInfo.new(1.5, Enum.EasingStyle.Sine), {FieldOfView = 35})
        tweenIn:Play()
        
        -- Sequence calibrada para preencher os 8.5 segundos inteiros da animação
        task.spawn(function()
            showDialog(Player.DisplayName or Player.Name, "I'm trying to think of what to do right now...")
            task.wait(2.5)
            showDialog(Player.DisplayName or Player.Name, "T-THIS ARROW!")
            task.wait(2.0)
            showDialog(Player.DisplayName or Player.Name, "Hahahaha.")
            task.wait(3.0)
            
            hideDialog()
            local tweenOut = TS:Create(camera, TweenInfo.new(1.0, Enum.EasingStyle.Sine), {FieldOfView = originalFOV})
            tweenOut:Play()
            task.wait(1.0)
            
            isStunned = false
            currentAction = nil
            animRageEntry.weight = 0
            setSpeed(SPEED_WALK)
        end)
    end

    local function updateUI()
        if not guiRef then return end
        local c = guiRef:FindFirstChild("Container")
        if not c then return end
        
        local awkBar = c:FindFirstChild("AwkBar")
        local slotCont = c:FindFirstChild("SlotContainer")
        
        if isRaging then
            if awkBar then awkBar.Text = "BASE [G]" end
            if slotCont then
                slotCont.Slot1.Text = "1\nBite The Dust"
                slotCont.Slot2.Visible = false
                slotCont.Slot3.Visible = false
            end
        else
            if awkBar then awkBar.Text = "QUEEN'S GAMBIT [G]" end
            if slotCont then
                slotCont.Slot1.Text = "1\nSheer Heart\nAttack"
                slotCont.Slot2.Visible = true
                slotCont.Slot3.Visible = true
            end
        end
    end

    local function toggleAwakening()
        if isStunned then return end
        stopAction()
        
        isRaging = not isRaging
        updateUI()
        
        if isRaging then
            doAwakeningCutscene()
        else
            currentAction = nil
            setBase("idle")
        end
    end

    local function playAction(name)
        if currentAction or isStunned then return end
        stopAction()
        
        currentAction  = name
        flingActive    = m.FlingEnabled[name] == true
        
        local a = actionAnims[name]
        if a then
            a.weight = 1
            actionStart[a] = os.clock()
        end
        
        if name == "Sheer Heart Attack" then 
            if snd_Sheer_Heart_Attack then snd_Sheer_Heart_Attack:Play() end
            applyStun(3)
            
        elseif name == "Head Slam" then 
            if snd_Head_Slam then snd_Head_Slam:Play() end
            applyStun(3.5)
            local randPlr = getRandomPlayer()
            spawnRigWithAppearance(randPlr, CFrame.new(0, 0, -3.5) * CFrame.Angles(0, math.pi, 0), "Victim.anim", 3.5)
            
        elseif name == "Bite the Dust" then 
            if snd_Bite_the_Dust then snd_Bite_the_Dust:Play() end
            applyStun(32)
            
            task.spawn(function()
                showDialog("Yoshikage Kira", "KILLER QUEEN DAISAN NO BAKUDAN, BITES THE DUST!")
                task.wait(4)
                hideDialog()
            end)
            
        elseif name == "Face Explosion" then
            if snd_Face_Explosion then snd_Face_Explosion:Play() end
            applyStun(5)
            local randPlr = getRandomPlayer()
            -- Cria o rig 1 passo a frente (CFrame.new(0, 0, -3)) virado para o jogador
            spawnRigWithAppearance(randPlr, CFrame.new(0, 0, -3) * CFrame.Angles(0, math.pi, 0), "3_Skill_Base_V.anim", 5)
        end
    end

    -- UI BUILDER
    local function createButton(parent, name, text, layoutOrder)
        local btn = Instance.new("TextButton")
        btn.Name = name
        btn.Size = UDim2.new(0, 75, 0, 75)
        btn.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
        btn.BackgroundTransparency = 0.2
        btn.BorderColor3 = Color3.fromRGB(150, 0, 200)
        btn.BorderSizePixel = 2
        btn.Text = text
        btn.TextColor3 = Color3.fromRGB(255, 255, 255)
        btn.TextScaled = true
        btn.Font = Enum.Font.GothamBold
        btn.LayoutOrder = layoutOrder
        btn.Parent = parent
        
        local padding = Instance.new("UIPadding")
        padding.PaddingTop = UDim.new(0, 4)
        padding.PaddingBottom = UDim.new(0, 4)
        padding.PaddingLeft = UDim.new(0, 4)
        padding.PaddingRight = UDim.new(0, 4)
        padding.Parent = btn
        
        return btn
    end

    local function setupFlingTouched(figure)
        local function hookPart(part)
            local conn = part.Touched:Connect(function(hit)
                if not flingActive then return end
                if not hit or not hit.Parent then return end
                local target = hit.Parent
                if target:IsA("Accessory") then target = target.Parent end
                if target == figure then return end
                if not target:FindFirstChildOfClass("Humanoid") then return end
                ReanimateFling(target)
            end)
            table.insert(touchConns, conn)
        end
        for _, part in ipairs(figure:GetDescendants()) do
            if part:IsA("BasePart") then hookPart(part) end
        end
        table.insert(touchConns, figure.DescendantAdded:Connect(function(part)
            if part:IsA("BasePart") then hookPart(part) end
        end))
    end

    -- INIT
    m.Init = function(figure)
        figureRef = figure
        local hrp = figure:FindFirstChild("HumanoidRootPart") or figure

        allJoints = {}
        for _, v in ipairs(figure:GetDescendants()) do
            if v:IsA("Motor6D") then table.insert(allJoints, v) end
        end

        baseAnims = {
            idle = loadAnim(figure, "Kage.anim", true),
            walk = loadAnim(figure, "NewRun.anim", true),
            jump = loadAnim(figure, "Test.anim", true),
        }

        actionAnims = {
            ["Sheer Heart Attack"] = loadAnim(figure, "HeartAttack.anim", false),
            ["Head Slam"] = loadAnim(figure, "Skill_2_Acerto.anim", false),
            ["Bite the Dust"] = loadAnim(figure, "Stand_BTD.anim", false),
            ["Face Explosion"] = loadAnim(figure, "3_Skill_Base_U.anim", false),
        }

        bgSound = makeSound("", hrp, 0.5, true)
        bgSound:Play()

        snd_Sheer_Heart_Attack = makeSound("Skill_1.mp3", hrp, 1, false)
        snd_Head_Slam = makeSound("Skill2_Victim.mp3", hrp, 1, false)
        snd_Face_Explosion = makeSound("3_Skill_base.mp3", hrp, 1, false)
        snd_Bite_the_Dust = makeSound("Skill_3.mp3", hrp, 1, false)
        sndRage = makeSound("Awk.mp3", hrp, 1, false)
        
        animRageEntry = loadAnim(figure, "Awakening.anim", false)

        setSpeed(SPEED_WALK)
        setBase("idle")
        setupFlingTouched(figure)

        -- === BUILD DIALOG UI ===
        dialogGuiRef = Instance.new("ScreenGui")
        dialogGuiRef.Name = "KiraDialogUI"
        dialogGuiRef.ResetOnSpawn = false
        dialogGuiRef.Enabled = false
        dialogGuiRef.Parent = Player:WaitForChild("PlayerGui")
        
        local dFrame = Instance.new("Frame", dialogGuiRef)
        dFrame.Name = "DialogFrame"
        dFrame.AnchorPoint = Vector2.new(0.5, 0.5)
        dFrame.Position = UDim2.new(0.5, 0, 0.75, 0)
        dFrame.Size = UDim2.new(0, 400, 0, 80) 
        dFrame.BackgroundTransparency = 1
        
        local nameLbl = Instance.new("TextLabel", dFrame)
        nameLbl.Name = "NameLabel"
        nameLbl.Size = UDim2.new(1, 0, 0, 25)
        nameLbl.Position = UDim2.new(0, 0, 0, 0)
        nameLbl.Font = Enum.Font.GothamBold
        nameLbl.TextSize = 18 
        nameLbl.TextColor3 = Color3.fromRGB(150, 0, 200)
        nameLbl.TextStrokeTransparency = 0
        nameLbl.BackgroundTransparency = 1
        
        local textLbl = Instance.new("TextLabel", dFrame)
        textLbl.Name = "TextLabel"
        textLbl.Size = UDim2.new(1, 0, 1, -25)
        textLbl.Position = UDim2.new(0, 0, 0, 25)
        textLbl.Font = Enum.Font.GothamMedium
        textLbl.TextSize = 16 
        textLbl.TextColor3 = Color3.fromRGB(255, 255, 255)
        textLbl.TextStrokeTransparency = 0
        textLbl.TextWrapped = true
        textLbl.BackgroundTransparency = 1

        -- === BUILD MOVESET UI ===
        guiRef = Instance.new("ScreenGui")
        guiRef.Name = "KiraBattlegroundsUI"
        guiRef.ResetOnSpawn = false
        guiRef.Parent = Player:WaitForChild("PlayerGui")

        local container = Instance.new("Frame", guiRef)
        container.Name = "Container"
        container.Size = UDim2.new(0, 300, 0, 120) 
        container.Position = UDim2.new(0.5, 0, 1, -20)
        container.AnchorPoint = Vector2.new(0.5, 1)
        container.BackgroundTransparency = 1

        -- Rectangle Awk Bar (Top)
        local awkBar = Instance.new("TextButton", container)
        awkBar.Name = "AwkBar"
        awkBar.Size = UDim2.new(1, 0, 0, 35) 
        awkBar.Position = UDim2.new(0, 0, 0, 0)
        awkBar.BackgroundColor3 = Color3.fromRGB(150, 20, 30)
        awkBar.BorderColor3 = Color3.fromRGB(10, 10, 10)
        awkBar.BorderSizePixel = 2
        awkBar.Text = "QUEEN'S GAMBIT [G]"
        awkBar.TextColor3 = Color3.fromRGB(255, 255, 255)
        awkBar.Font = Enum.Font.GothamBold
        awkBar.TextSize = 16 
        awkBar.AutoButtonColor = true

        -- Base Moves Container (Bottom)
        local slotCont = Instance.new("Frame", container)
        slotCont.Name = "SlotContainer"
        slotCont.Size = UDim2.new(1, 0, 0, 80) 
        slotCont.Position = UDim2.new(0, 0, 0, 40)
        slotCont.BackgroundTransparency = 1

        local list = Instance.new("UIListLayout", slotCont)
        list.FillDirection = Enum.FillDirection.Horizontal
        list.HorizontalAlignment = Enum.HorizontalAlignment.Center
        list.SortOrder = Enum.SortOrder.LayoutOrder
        list.Padding = UDim.new(0, 10)

        local btn1 = createButton(slotCont, "Slot1", "1\nSheer Heart\nAttack", 1)
        local btn2 = createButton(slotCont, "Slot2", "2\nHead Slam", 2)
        local btn3 = createButton(slotCont, "Slot3", "3\nFace\nExplosion", 3)
        
        updateUI()

        -- CONNECTIONS
        btn1.Activated:Connect(function() 
            if isRaging then playAction("Bite the Dust") else playAction("Sheer Heart Attack") end
        end)
        btn2.Activated:Connect(function() if not isRaging then playAction("Head Slam") end end)
        btn3.Activated:Connect(function() if not isRaging then playAction("Face Explosion") end end)
        awkBar.Activated:Connect(function() toggleAwakening() end)

        inputConn = UIS.InputBegan:Connect(function(input, gp)
            if gp then return end
            if input.KeyCode == Enum.KeyCode.One then
                if isRaging then playAction("Bite the Dust") else playAction("Sheer Heart Attack") end
            elseif input.KeyCode == Enum.KeyCode.Two then
                if not isRaging then playAction("Head Slam") end
            elseif input.KeyCode == Enum.KeyCode.Three then
                if not isRaging then playAction("Face Explosion") end
            elseif input.KeyCode == Enum.KeyCode.G then
                toggleAwakening()
            end
        end)
    end

    -- UPDATE
    m.Update = function(dt, figure)
        local hum = figure:FindFirstChildOfClass("Humanoid")
        if not hum then return end
        
        local now = os.clock()
        local inAir = hum.FloorMaterial == Enum.Material.Air

        -- Handle Action Durations
        if currentAction then
            local activeAnim = actionAnims[currentAction]
            if currentAction == "Awakening" then activeAnim = animRageEntry end
            
            local targetDuration = actionDurations[currentAction] or 0
            
            if activeAnim and actionStart[activeAnim] then
                local elapsed = now - actionStart[activeAnim]
                if targetDuration > 0 and elapsed >= targetDuration / (activeAnim.speed or 1) then
                    activeAnim.weight = 0
                    currentAction = nil
                    flingActive = false
                end
            elseif not activeAnim then
                if not isStunned then
                    currentAction = nil
                    flingActive = false
                end
            end
        end

        -- Handle Base Movement States
        if not currentAction and not isStunned then
            if inAir then
                setBase("jump")
            else
                local moving = hum.MoveDirection.Magnitude > 0.1
                if moving then
                    setBase("walk")
                else
                    setBase("idle")
                end
            end
        elseif isStunned and currentAction ~= "Awakening" then
            setBase("idle")
        end

        -- Step Animations
        for _, a in pairs(baseAnims) do 
            if a.weight > 0 and actionStart[a] then 
                a:Step(now - actionStart[a]) 
            end 
        end
        
        if animRageEntry and animRageEntry.weight > 0 and actionStart[animRageEntry] then 
            animRageEntry:Step(now - actionStart[animRageEntry]) 
        end
        
        for name, a in pairs(actionAnims) do 
            if a.weight > 0 and actionStart[a] then 
                a:Step(now - actionStart[a]) 
            end 
        end
        
        for i = #activeVictims, 1, -1 do
            local vData = activeVictims[i]
            if vData.dummy and vData.dummy.Parent then
                vData.anim:Step(now - vData.start)
            else
                table.remove(activeVictims, i)
            end
        end
    end

    -- DESTROY
    m.Destroy = function(figure)
        if inputConn then inputConn:Disconnect() inputConn = nil end
        if guiRef then guiRef:Destroy() guiRef = nil end
        if dialogGuiRef then dialogGuiRef:Destroy() dialogGuiRef = nil end
        
        -- Restore Camera if broken
        local camera = workspace.CurrentCamera
        TS:Create(camera, TweenInfo.new(0.5), {FieldOfView = 70}):Play()

        for _, conn in ipairs(touchConns) do conn:Disconnect() end
        table.clear(touchConns)

        if bgSound then bgSound:Stop() bgSound:Destroy() bgSound = nil end
        stopAllAnimSounds()
        if snd_Sheer_Heart_Attack then snd_Sheer_Heart_Attack:Destroy() snd_Sheer_Heart_Attack = nil end
        if snd_Head_Slam then snd_Head_Slam:Destroy() snd_Head_Slam = nil end
        if snd_Face_Explosion then snd_Face_Explosion:Destroy() snd_Face_Explosion = nil end
        if snd_Bite_the_Dust then snd_Bite_the_Dust:Destroy() snd_Bite_the_Dust = nil end
        if animRageEntry then animRageEntry.weight = 0 end
        if sndRage then sndRage:Destroy() sndRage = nil end

        for _, vData in ipairs(activeVictims) do
            if vData.dummy then vData.dummy:Destroy() end
        end
        activeVictims = {}

        for _, joint in ipairs(allJoints) do
            if joint and joint.Parent then joint.Transform = CFrame.identity end
        end
        allJoints = {}

        for _, a in pairs(baseAnims)   do a.weight = 0 end
        for _, a in pairs(actionAnims) do a.weight = 0 end

        setSpeed(16)
        actionStart   = {}
        currentAction = nil
        currentBase   = "idle"
        wasInAir      = false
        flingActive   = false
        figureRef     = nil
        baseAnims     = {}
        actionAnims   = {}
        isSprinting   = false
        isRaging      = false
        isStunned     = false
        stunToken     = 0
    end

    return m
end)

return modules